This is a compiler built for RPAL language.

use ./mypal file_name to compile and run a program

use ./mypal file_name -ast to print the Abstract syntax tree
